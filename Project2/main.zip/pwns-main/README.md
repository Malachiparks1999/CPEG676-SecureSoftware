# PWN Assignments

These 16 problems are re-mixes of a beautiful set of introductory vulnerabilities from the 2020 Sunshine CTF.  I have the original binaries at: https://github.com/AndyNovo/speedruns
 
You can find write-ups of those problems when you get stuck, but these will have their own attributes that are adjusted for you.

We will release the problems in batches over the 7-weeks of this course.

Good luck, ask lots of questions.
