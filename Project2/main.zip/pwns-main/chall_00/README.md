# Chall 00 Basic Memory Corruption
Compiled with `gcc main.c -fno-stack-protector`. 
